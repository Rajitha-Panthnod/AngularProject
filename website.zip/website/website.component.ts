import { Component } from '@angular/core';

@Component({
  selector: 'app-website',
  templateUrl: './website.component.html',
  styleUrls: ['./website.component.css']
})
export class WebsiteComponent 
{

  
             thumbolian1=false;
             thumbolian2=false;
             thumbolian3 = false;
             back=true;
             register(choice:any)
              {
                 this.back=false;
                 this.thumbolian1=false;
                 this.thumbolian2=false;
                 this.thumbolian3=false;
                 if(choice==1)
                 {
                    this.thumbolian1=true;
                  }
                 else if(choice==2)
                {
                  this.thumbolian2=true;
                }
                 else if(choice ==3)
                 {
                  this.thumbolian3=true;
                 }

   
              }
   mainpageinformation()
    {
   this.thumbolian1=false;
   this.thumbolian2=false;
   this.thumbolian3=false;
   this.back=true; 
   }

}
