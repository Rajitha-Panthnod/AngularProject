import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thumbolian2',
  templateUrl: './thumbolian2.component.html',
  styleUrls: ['./thumbolian2.component.css']
})
export class Thumbolian2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
