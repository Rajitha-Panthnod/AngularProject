import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Thumbolian2Component } from './thumbolian2.component';

describe('Thumbolian2Component', () => {
  let component: Thumbolian2Component;
  let fixture: ComponentFixture<Thumbolian2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Thumbolian2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Thumbolian2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
