import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thumbolian1',
  templateUrl: './thumbolian1.component.html',
  styleUrls: ['./thumbolian1.component.css']
})
export class Thumbolian1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
