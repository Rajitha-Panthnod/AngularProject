import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Thumbolian1Component } from './thumbolian1.component';

describe('Thumbolian1Component', () => {
  let component: Thumbolian1Component;
  let fixture: ComponentFixture<Thumbolian1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Thumbolian1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Thumbolian1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
