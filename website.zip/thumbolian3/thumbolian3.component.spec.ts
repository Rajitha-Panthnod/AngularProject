import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Thumbolian3Component } from './thumbolian3.component';

describe('Thumbolian3Component', () => {
  let component: Thumbolian3Component;
  let fixture: ComponentFixture<Thumbolian3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Thumbolian3Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Thumbolian3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
