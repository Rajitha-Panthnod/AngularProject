import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thumbolian3',
  templateUrl: './thumbolian3.component.html',
  styleUrls: ['./thumbolian3.component.css']
})
export class Thumbolian3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
